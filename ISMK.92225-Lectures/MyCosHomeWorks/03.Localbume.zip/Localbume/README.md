# ![localbume-logo](https://raw.githubusercontent.com/coshkun/localbume/master/Resources/Icon/Icon-40.png) Localbume 
Localbume is a location based iOS app, what makes you collect and archive your personal location history tagged by photos. You can collect and share your best places with your best moments as an album style, and you can plan or record your own adventures.

#### Version 1.0
* Position Finder Added
* Error Handlers Added

#### Screenshot
![localbume-launch-image](https://raw.githubusercontent.com/coshkun/localbume/master/Resources/Launch%20Images/Launch%20Image%202x.png)