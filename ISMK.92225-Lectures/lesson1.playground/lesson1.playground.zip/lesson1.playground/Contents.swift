//: Playground - noun: a place where people can play

import UIKit
/*
//Veri Türleri


//let lname = "Yılmaz"
var age : Int = 28
var age2 = 21
//print("Adı : \(name) Soyadı: \(lname) Yaşı: \(age)")

let n1 = 11
let result = (n1 + 2) * 3

//convert


let integer : Int = 10
let double : Double = 11.3
//let result2 : Double = Double(integer * double)

//
let isEquals : Bool = (1 == 1)
let isEquals2 : Bool = (1 < 1)
let isEquals3 = (1 == 1) && true
let isEquals4 = false || true

////////////lesson 2 

let hourOfDay = 12
var timeOfDay : String
let name = "Yunus"

if hourOfDay < 6 {
    timeOfDay = "Early morning"
}else if hourOfDay < 12 {
    timeOfDay = "Afternon"
}
else {
    timeOfDay = "Evening"
}
 */
/*
print(" \(timeOfDay)")

if 1 < 2 && name == "Yunus" {
    //print("true")
    if name == "Yılmaz" {
        print("")
    }
    else {
        print("")
    }
}
else {
    print("")
}
if 3 == 3 || name == "Yılmaz" {
    print("veya")
}
//scope kavramı

var houseWorked = 45

var price = 0

if houseWorked < 40 {
   // let houseWorked = houseWorked - 40 hata çünkü global scope local scope'u ezer.
    price += houseWorked
}
//? operator
let a = 10
let b : Int = 20

let min = a < b ? a : b
let max = a > b ? a : b

//loops

//while loop

var sum = 1

while sum < 10 {
    sum += 1
    //print(sum)
}
 */ /*
sum = 0
repeat {
    print(sum)
    sum += 1
} while sum == 0
print(sum)

while true {
    sum += 1
    if sum >= 100 {
        break
    }
    print(sum)
}
*/

//////////////////////////////////////////////
///////////////////////15.05.2017
let a = 5
let b = 10

let min : Int

if a < b {
    min = a
}
else
{
    min = b
}

/// 
/*
Eşit değil : !=
Küçük / büyük : <>
Küçük eşit / büyük eşit : <= >=
*/
//Ranges 


let closedRange = 0...5 //0, 1, 2, 3, 4, 5

//for loops 

let count = 10
var sum = 0

for i in 1...count {
    sum += i
}
print(sum)

for _ in 1...count {
    print("tag")
}

for i in 1...count where i % 2 == 1 {
    print("where")
}
print(sum)

///örnek

let row = 0
let column = 0


for row in 0..<8 {
    if row % 2 == 0 {
        continue
    }
    
    for column in 0..<8 {
        //print(row * column)
    }
}

///
for row in 0..<8 where row % 2 == 1{
    for column in 0..<8 {
        print(row * column)
    }
}
//switch

let numberForSwitch = 10

switch numberForSwitch {
case 5, 10:
    print("5 veya 10")
default:
    print("hicbiri")
}

let nameForSwitch = "Dog"

switch nameForSwitch {
case "Dog", "Cat":
    print(nameForSwitch)
case "bla" :
    print(nameForSwitch)
default:
    print("Hiçbiri")
}

switch numberForSwitch {
case 0...5: //with range
    print(numberForSwitch)
default:
    print(numberForSwitch)
}

switch numberForSwitch {
case _ where numberForSwitch % 2 == 0:
    print("Çift sayı")
default:
    print("Tek sayı")
}
//functions

func printMyName() {
    print("Yunus")
}


printMyName()

func sum(operand1: Int, operand2: Int) -> Int{
    return operand1 + operand2
}

sum(operand1: 5, operand2: 20)
//with tag
func multply(first operand1: Int, last operand2: Int) -> Int {
    return operand1 * operand2
}

func multply(_ operand1: Int, _ operand2: Int) -> Int {
    return operand1 * operand2
}

multply(11, 22)


