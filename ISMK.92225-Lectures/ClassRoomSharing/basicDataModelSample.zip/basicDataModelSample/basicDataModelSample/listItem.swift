//
//  listItem.swift
//  basicDataModelSample
//
//  Created by iosDev on 1.08.2017.
//  Copyright © 2017 iosDev. All rights reserved.
//

import Foundation

class listItem {
    var text = ""
    var checked = false
    
    func toggleCheck() {
        checked = !checked
    }
}
