//
//  ListView.swift
//  basicDataModelSample
//
//  Created by iosDev on 1.08.2017.
//  Copyright © 2017 iosDev. All rights reserved.
//

import UIKit

class ListView: UITableViewController, ItemDetailViewControllerDelegate {

    var items : [listItem]
    
    required init?(coder aDecoder: NSCoder) {
        
        items = [listItem]()
        
        let row0 = listItem()
        row0.text = "Sample1"
        row0.checked = false
        items.append(row0)
       
        let row1 = listItem()
        row1.text = "Sample2"
        row1.checked = true
        items.append(row1)
        
        let row2 = listItem()
        row2.text = "Sample3"
        row2.checked = false
        items.append(row2)
        
        super.init(coder: aDecoder)
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func addItem(_ sender: UIBarButtonItem) {
        let rowCount = items.count
        
        let item = listItem()
        item.text = "AddSample"
        item.checked = true
        items.append(item)
        let indexPath = IndexPath(row: rowCount, section: 0)
        let indexPaths = [indexPath]
        tableView.insertRows(at: indexPaths, with: .automatic)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    // MARK: - Table view data source

   
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return items.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let item = items[indexPath.row]
        // Configure the cell...
        configureText(for: cell, item: item)
        configureCheckMark(for: cell, item: item)
        return cell
    }
    func configureText(for cell:UITableViewCell, item: listItem){
        let label = cell.viewWithTag(1000) as! UILabel
        label.text = item.text
    }
    func configureCheckMark(for cell:UITableViewCell, item: listItem) {
        if item.checked {
            cell.accessoryType = .checkmark
        }
        else
        {
            cell.accessoryType = .none
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) {
            let item = items[indexPath.row]
            item.toggleCheck()
            configureCheckMark(for: cell, item: item)
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        items.remove(at: indexPath.row)
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
    }
    func itemDetailViewControllerDidCancel(_ controller: AddAndEditItem)
    {
        dismiss(animated: true, completion: nil)
    }
    func itemDetailViewController(_ controller: AddAndEditItem, didFinishAdding item:listItem)
    {
        let index = items.count
        items.append(item)
        
        let indexPath = IndexPath(row: index, section: 0)
        let indexPaths = [indexPath]
        tableView.insertRows(at: indexPaths, with: .automatic)
        dismiss(animated: true, completion: nil)
        
    }
    func itemDetailViewController(_ controller: AddAndEditItem, didFinishEditing item:listItem)
    {
        //burada kalındı
    }
}
