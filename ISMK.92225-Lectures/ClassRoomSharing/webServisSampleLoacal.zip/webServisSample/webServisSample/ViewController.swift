//
//  ViewController.swift
//  webServisSample
//
//  Created by iosDev on 21.08.2017.
//  Copyright © 2017 iosDev. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, XMLParserDelegate {

    var m_data:[String] = []
    var m_selectedItem : String?
    var m_elementName = String()
    var m_dName : String?
    var m_dVal : String?
    
    
    @IBOutlet weak var dovizPicker: UIPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let url : String = "http://www.tcmb.gov.tr/kurlar/today.xml"
        let urltoSend : URL = URL(string: url)!
        
        let parser = XMLParser(contentsOf: urltoSend)
        parser?.delegate = self
        
        let success = parser?.parse()
        if !(success!) {
            print("Hata! bağlantı yapılamadı")
        }
        //picker view
        self.dovizPicker.delegate = self
        self.dovizPicker.dataSource = self
        //JSON
        
        let urlJSOn :URL = URL(string: "https://api.whitehouse.gov/v1/petitions.json?limit=100")!
        Alamofire.request(urlJSOn, method: .get).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                //print("JSON: \(json)")
                self.parse(json: json)
            case .failure(let error):
                print(error)
            }
        }
        
        
    }
    func parse(json: JSON) {
        for result in json["results"].arrayValue {
            let title = result["title"].stringValue
            let body = result["body"].stringValue
            let sigs = result["signatureCount"].stringValue
            let obj = ["title": title, "body": body, "sigs": sigs]
            print(obj)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    //xml kaynağındaki açılış taglerini yakalar
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        m_elementName = elementName
        if m_elementName == "Currency" {
            m_dName = String()
            m_dVal = String()
        }
    }
    //xml kaynağından karakter okuma işlemi yapar
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let data = string.trimmingCharacters(in: .whitespacesAndNewlines)
        if !data.isEmpty {
            if m_elementName == "CurrencyName" {
                m_dName = data
            }
            else if m_elementName == "ForexBuying" {
                m_dVal = data
            }
        }
    }
    //xml kapanış taglerini yakalar
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let tempString = "\(m_dName ?? "") : \(m_dVal ?? "")"
        print(tempString)
        m_data.append(tempString)
    }
    //xml parse hata oluşursa
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("hata oluştu: \(parseError.localizedDescription)")
    }
    //pickerview delegate metotları
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return m_data.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return m_data[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if !(row > m_data.count){
            m_selectedItem = m_data[row] as String
            print("seçilen satır: \(m_selectedItem!)")
            performSegue(withIdentifier: "detail", sender: nil)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail" {
            let detail = segue.destination as! DetailViewController
            if let selectItem = m_selectedItem {
                detail.m_text = selectItem
            }
        }
    }
}

