//
//  DetailViewController.swift
//  webServisSample
//
//  Created by iosDev on 21.08.2017.
//  Copyright © 2017 iosDev. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var m_text : String?
    
    @IBOutlet weak var txt: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        txt.text = m_text!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
