//
//  ViewController.swift
//  sqliteSample
//
//  Created by iosDev on 16.08.2017.
//  Copyright © 2017 iosDev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var databasePath = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        dbFilePath()
    }

    @IBOutlet weak var txtId: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtDesc: UITextField!
    @IBAction func btnSave(_ sender: UIButton) {
        let queryStr = "INSERT INTO LIST (ID, NAME, DESCRIPTION) VALUES ('\(txtId.text!)', '\(txtName.text!)', '\(txtDesc.text!)')"
        if self.insertDb(queryStr) {
            print("successfuly saved")
        }
        else {
            print("error! save")
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func dbFilePath() {
        let filemanager = FileManager.default
        let filepath = filemanager.urls(for: .documentDirectory, in: .userDomainMask)
        databasePath = (filepath[0].appendingPathComponent("ListDB").path as NSString) as String
    }
    func insertDb(_ sqlString: String)->Bool {
        let mydb = FMDatabase(path: databasePath)
        if (mydb?.open())! {
            let sqlStr = mydb?.executeUpdate(sqlString, withArgumentsIn: nil)
            if !(sqlStr!) {
                print("insertDB error \(mydb?.lastError())")
                mydb?.close()
                return false
            }
        }
       mydb?.close()
         return true
    }

}

